/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * MicroMMC Stack Controller
 * Author: Chuantong Hao
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "tim.h"
#include "usb_device.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

#include "usbd_cdc_if.h"
#define LED1_On() HAL_GPIO_WritePin(GPIOE, GPIO_PIN_2, 1);
#define LED2_On() HAL_GPIO_WritePin(GPIOE, GPIO_PIN_3, 1);
#define LED1_Off() HAL_GPIO_WritePin(GPIOE, GPIO_PIN_2, 0);
#define LED2_Off() HAL_GPIO_WritePin(GPIOE, GPIO_PIN_3, 0);
#define Stack_R_Insert() HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, 0);  // Relay = 0: Insert the charging resistor
#define Stack_R_Bypass() HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, 1);  // Relay = 1: Bypass the charging resistor

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

uint8_t USB_RX[2] = {168, 168};
uint8_t USB_TX[4] = {2, 44, 99, 33};

uint8_t Precharge_State = 1;// 1: uncontrolled pre-charge; 2: controlled pre-charge; 0: normal operation

uint32_t i_USBcom;

/*Input Capture Channels of Micro MMC V2, 8 Channels of TIM2 TIM4
 *SM1: TIM2 CH2; *SM2: TIM2 CH4; *SM3: TIM4 CH1; *SM4: TIM2 CH3;
 *SM5: TIM4 CH4; *SM6: TIM4 CH2; *SM7: TIM2 CH1; *SM8: TIM4 CH3; */

uint8_t capture_Flag[8] = {0,0,0,0,0,0,0,0};      //Input Capture Flag
uint32_t capture_1stedge[8] = {0,0,0,0,0,0,0,0};  //Input Capture Counting 1st raising edge
uint32_t capture_2ndedge[8] = {0,0,0,0,0,0,0,0};  //Input Capture Counting 2nd raising edge
uint8_t Vsm_Flag[8] = {0,0,0,0,0,0,0,0};          //If error 2 times, block

uint16_t Input_PWM_Period[8] = {0,0,0,0,0,0,0,0};    //Input PWM Period

// Stack voltage references
float Vref_top = 8;
float Vref_bottom = 8;

// SM voltage
float Vsm_top[4] = {0,0,0,0};       //SM voltage, Real Value*1e4
float Vsm_bottom[4] = {0,0,0,0};       //SM voltage, Real Value*1e4
float Vsm_phase[8] = {0,0,0,0,0,0,0,0};


// SM voltage bounds
float Vsm_Max = 16;
float Vsm_Min = 0;


// Average SM voltage of each stack, real value
float Vsm_top_Aver = 0;
float Vsm_bottom_Aver = 0;
float Vsm_Aver = 0;

float Vdc = 20;


// Energy deviation in SM capacitors
float Estack_top = 0;
float Estack_bottom = 0;
/* Better to send Estack to master rather than deltaEstack
 * Real Value * 1e4, E = Nsm * 1/2 * Csm * Vsm^2, C = 6800uF
 * Csm = 3 *C = 20.4e-3, Vsm_range = 0 - 10V
 * Estack_uint16 = 0 ~ 40800
 * uint8: 0 - 255
 * */

// Number of SMs being inserted
float N_Insert_top = 0;
float N_Insert_bottom = 0;
float N_Insert_phase = 0;

// Current measurement: Voltage of ADC pins(output of the current sensors)
float Vadc_top = 0;
float Vadc_bottom = 0;

// Measured current in float
float I_top;
float I_bottom;

// Current bound in float
float Is_Max = 5;
float Is_Min = -5;

// SM insert orders
uint8_t SM_Insert_Order_top[] = {0,0,0,0};
uint8_t SM_Insert_Order_bottom[] = {0,0,0,0};
uint8_t SM_Insert_Order_phase[] = {0,0,0,0,0,0,0,0};

/* SM states: fpwm = 10k, fully inserted (100),  fully bypassed (0)
              fpwm = 1k,  fully inserted (1000), fully bypassed (0)*/
uint16_t SM_State_top[] = {0,0,0,0};  // 0~100
uint16_t SM_State_bottom[] = {0,0,0,0};  // 0~100
uint16_t SM_State_phase[] = {0,0,0,0,0,0,0,0};  // 0~100

uint8_t Cycle = 0;

uint8_t Flag_Error = 0;

void Update_Vref(void);
void Read_SM_Voltage(void);
void Read_Stack_Current(void);
void Hct_PWM_Init(void);
void Hct_SM_Enable(void);
void Hct_SM_Disable(void);
void SM_Sorting(void);
void SM_State_Setting(void);
void SM_PWM_Generation(void);
void Error_Alert(void);
void PreCharge_Stage2(void);

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */


  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_ADC1_Init();
  MX_TIM1_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  MX_TIM4_Init();
  MX_TIM5_Init();
  MX_TIM8_Init();
  MX_TIM9_Init();
  MX_TIM12_Init();
  MX_ADC2_Init();
  MX_USB_DEVICE_Init();
  /* USER CODE BEGIN 2 */
  LED2_On();
  Stack_R_Insert();

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	  /*//*/
	  if (Flag_Error == 0) {
		  Read_SM_Voltage();
		  Read_Stack_Current();

		  // Uncontrolled Pre-charge Stage 1 When Vdc = 20V, SM can be charge to about 1.1V.
		  if(Precharge_State == 1) {
			  Stack_R_Insert();  // Relay = 0: Insert the charging resistor
			  Hct_SM_Disable();
			  if(Vsm_Aver > 1){
				  Precharge_State = 2;
			  }
		  }
		  // Controlled Pre-charge Stage 2
		  else if (Precharge_State == 2) {
			  Update_Vref();
			  PreCharge_Stage2();
		  }
		  else {// Normal Operation
			  if(Vsm_top_Aver < 1.2 || Vsm_bottom_Aver < 1.2){
				  Precharge_State = 2;// Controlled pre-charge
				  }
			  Stack_R_Bypass();  // Relay = 1: Bypass the charging resistor
			  Hct_PWM_Init();
			  Hct_SM_Enable();
			  if(Cycle == 0){
				  //Read_Stack_Current();
				  SM_Sorting();
			  }
			  Update_Vref();
			  SM_State_Setting();
			  SM_PWM_Generation();
			  ++ Cycle;
		  }

	} else {
		Error_Alert();
	}


  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 168;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 7;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV2;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
void PreCharge_Stage2(void)
{
	//Precharge_State = 2;

	if(Vsm_Aver > 3.9){
		Precharge_State = 0; // Normal Operation
	}

	//if(Vsm_Aver < 1){
	//	Precharge_State = 1;// uncontrolled pre-charge
	//}

	//Stack_R_Insert();  // Relay = 0: Insert the charging resistor
	Stack_R_Bypass();  // Relay = 1: Bypass the charging resistor
	Hct_PWM_Init();
	Hct_SM_Enable();

	for (uint8_t i = 0; i < 4; ++i) {
		Vsm_phase[i] = Vsm_top[i];
		Vsm_phase[i + 4] = Vsm_bottom[i];
	}
	for (uint8_t i = 0; i < 8; ++i) {SM_Insert_Order_phase[i] = i;}
	for (uint8_t i = 0; i < 8; ++i) {
		for (uint8_t j = i + 1; j < 8; ++j) {
			if (Vsm_phase[i] < Vsm_phase[j]) {
				SM_Insert_Order_phase[i] = SM_Insert_Order_phase[i] + 1;
				SM_Insert_Order_phase[j] = SM_Insert_Order_phase[j] - 1;}
		}
	}
	N_Insert_phase = 4;//Nsm
	/* Insert orders -> SM states: bypass or insert, fpwm = 1kHz: *1000   1000-1, fpwm = 10kHz: *100   100-1*/
	for (uint8_t i = 0; i < 8; ++i) {
		SM_State_phase[i] = N_Insert_phase * 100 + 100 * SM_Insert_Order_phase[i];
		if (SM_State_phase[i] > 800) {
			SM_State_phase[i] = 800;
		}else if (SM_State_phase[i] < 700) {
			SM_State_phase[i] = 700;
		}
		SM_State_phase[i] = SM_State_phase[i] - 700;
	}

	__HAL_TIM_SET_COMPARE(&htim5, TIM_CHANNEL_1, SM_State_phase[4]);
	__HAL_TIM_SET_COMPARE(&htim5, TIM_CHANNEL_3, 0);

	__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3, SM_State_phase[5]);
	__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_4, 0);

	__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, SM_State_phase[6]);
	__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, 0);

	__HAL_TIM_SET_COMPARE(&htim12, TIM_CHANNEL_1, SM_State_phase[7]);
	__HAL_TIM_SET_COMPARE(&htim12, TIM_CHANNEL_2, 0);

	__HAL_TIM_SET_COMPARE(&htim9, TIM_CHANNEL_1, SM_State_phase[0]);
	__HAL_TIM_SET_COMPARE(&htim9, TIM_CHANNEL_2, 0);

	__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, SM_State_phase[1]);
	__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, 0);

	__HAL_TIM_SET_COMPARE(&htim8, TIM_CHANNEL_4, SM_State_phase[2]);
	__HAL_TIM_SET_COMPARE(&htim8, TIM_CHANNEL_3, 0);

	__HAL_TIM_SET_COMPARE(&htim8, TIM_CHANNEL_1, SM_State_phase[3]);
	__HAL_TIM_SET_COMPARE(&htim8, TIM_CHANNEL_2, 0);
}


void Error_Alert(void)
{
	LED2_Off();
	HAL_GPIO_TogglePin(GPIOE, GPIO_PIN_2);
	Stack_R_Insert();
	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, 0);  // SM1
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2, 0);  // SM2
	HAL_GPIO_WritePin(GPIOE, GPIO_PIN_12, 0); // SM3
	HAL_GPIO_WritePin(GPIOD, GPIO_PIN_8, 0);  // SM4
	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, 0); // SM5
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, 0);  // SM6
	HAL_GPIO_WritePin(GPIOD, GPIO_PIN_7, 0);  // SM7
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, 0);  // SM8
	HAL_Delay(200);

}


void SM_PWM_Generation(void)
{
	/* If Vstack_ref >= 0, insert +; Else if Vstack_ref < 0, insert -. */
	if (Vref_bottom >= 0) {
		__HAL_TIM_SET_COMPARE(&htim5, TIM_CHANNEL_1, SM_State_bottom[0]);
		__HAL_TIM_SET_COMPARE(&htim5, TIM_CHANNEL_3, 0);

		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3, SM_State_bottom[1]);
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_4, 0);

		__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, SM_State_bottom[2]);
		__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, 0);

		__HAL_TIM_SET_COMPARE(&htim12, TIM_CHANNEL_1, SM_State_bottom[3]);
		__HAL_TIM_SET_COMPARE(&htim12, TIM_CHANNEL_2, 0);

	} else {
		__HAL_TIM_SET_COMPARE(&htim5, TIM_CHANNEL_1, 0);
		__HAL_TIM_SET_COMPARE(&htim5, TIM_CHANNEL_3, SM_State_bottom[0]);

		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3, 0);
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_4, SM_State_bottom[1]);

		__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 0);
		__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, SM_State_bottom[2]);

		__HAL_TIM_SET_COMPARE(&htim12, TIM_CHANNEL_1, 0);
		__HAL_TIM_SET_COMPARE(&htim12, TIM_CHANNEL_2, SM_State_bottom[3]);
	}

	if (Vref_top >= 0) {
		__HAL_TIM_SET_COMPARE(&htim9, TIM_CHANNEL_1, SM_State_top[0]);
		__HAL_TIM_SET_COMPARE(&htim9, TIM_CHANNEL_2, 0);

		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, SM_State_top[1]);
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, 0);

		__HAL_TIM_SET_COMPARE(&htim8, TIM_CHANNEL_4, SM_State_top[2]);
		__HAL_TIM_SET_COMPARE(&htim8, TIM_CHANNEL_3, 0);

		__HAL_TIM_SET_COMPARE(&htim8, TIM_CHANNEL_1, SM_State_top[3]);
		__HAL_TIM_SET_COMPARE(&htim8, TIM_CHANNEL_2, 0);

	} else {
		__HAL_TIM_SET_COMPARE(&htim9, TIM_CHANNEL_1, 0);
		__HAL_TIM_SET_COMPARE(&htim9, TIM_CHANNEL_2, SM_State_top[0]);

		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, 0);
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, SM_State_top[1]);

		__HAL_TIM_SET_COMPARE(&htim8, TIM_CHANNEL_4, 0);
		__HAL_TIM_SET_COMPARE(&htim8, TIM_CHANNEL_3, SM_State_top[2]);

		__HAL_TIM_SET_COMPARE(&htim8, TIM_CHANNEL_1, 0);
		__HAL_TIM_SET_COMPARE(&htim8, TIM_CHANNEL_2, SM_State_top[3]);
	}
}

void SM_State_Setting(void)
{
	/* Calculate absolute value of N_Insert*/

	if (Vref_top >= 0) {
		N_Insert_top = Vref_top / Vsm_top_Aver;
	}
	else {
		N_Insert_top = -Vref_top / Vsm_top_Aver;
	}

	if (Vref_bottom >= 0) {
		N_Insert_bottom = Vref_bottom / Vsm_bottom_Aver;
	}
	else {
		N_Insert_bottom = -Vref_bottom / Vsm_bottom_Aver;
	}
	/*N_Insert_top = 4;
	N_Insert_bottom = 4;*/


	/* Insert orders -> SM states: bypass or insert*/
	//fpwm = 1kHz: *1000   1000-1
	//fpwm = 10kHz: *100   100-1
	for (uint8_t i = 0; i < 4; ++i) {
		SM_State_top[i] = N_Insert_top * 100 + 100 * SM_Insert_Order_top[i];

		if (SM_State_top[i] > 400) {
			SM_State_top[i] = 400;
		}else if (SM_State_top[i] < 300) {
			SM_State_top[i] = 300;
		}

		SM_State_top[i] = SM_State_top[i] - 300;

		SM_State_bottom[i] = N_Insert_bottom * 100 + 100 * SM_Insert_Order_bottom[i];

		if (SM_State_bottom[i] > 400) {
			SM_State_bottom[i] = 400;
		}else if (SM_State_bottom[i] < 300) {
			SM_State_bottom[i] = 300;
		}

		SM_State_bottom[i] = SM_State_bottom[i] - 300;
	}
}

void SM_Sorting(void)
{
	for (uint8_t i = 0; i < 4; ++i) {
		SM_Insert_Order_top[i] = i;
		SM_Insert_Order_bottom[i] = i;
	}
	for (uint8_t i = 0; i < 4; ++i) {
		for (uint8_t j = i + 1; j < 4; ++j) {
			if (Vsm_top[i] < Vsm_top[j]) {
				SM_Insert_Order_top[i] = SM_Insert_Order_top[i] + 1;
				SM_Insert_Order_top[j] = SM_Insert_Order_top[j] - 1;
			}
			if (Vsm_bottom[i] < Vsm_bottom[j]) {
				SM_Insert_Order_bottom[i] = SM_Insert_Order_bottom[i] + 1;
				SM_Insert_Order_bottom[j] = SM_Insert_Order_bottom[j] - 1;
			}
		}
	}
	/* If the direction of stack voltage and current are different, the insert orders should be opposite*/
	if (Vref_top * I_top < 0) {
		for (uint8_t i = 0; i < 4; ++i) {
			SM_Insert_Order_top[i] = 3 - SM_Insert_Order_top[i];
		}
	}

	if (Vref_bottom * I_bottom < 0) {
		for (uint8_t i = 0; i < 4; ++i) {
			SM_Insert_Order_bottom[i] = 3 - SM_Insert_Order_bottom[i];
		}
	}
}

void Hct_PWM_Init(void)
{
// PWM initialisation of SMs in the bottom stack
	HAL_TIM_PWM_Start(&htim5, TIM_CHANNEL_1);  //SM5 PWM1
	HAL_TIM_PWM_Start(&htim5, TIM_CHANNEL_3);  //SM5 PWM2
	HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_3);  //SM6 PWM1
	HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_4);  //SM6 PWM2
	HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);  //SM7 PWM1
	HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_2);  //SM7 PWM2
	HAL_TIM_PWM_Start(&htim12, TIM_CHANNEL_1); //SM8 PWM1
	HAL_TIM_PWM_Start(&htim12, TIM_CHANNEL_2); //SM8 PWM2

// PWM initialisation of SMs in the top stack
	HAL_TIM_PWM_Start(&htim9, TIM_CHANNEL_1);  //SM1 PWM1
	HAL_TIM_PWM_Start(&htim9, TIM_CHANNEL_2);  //SM1 PWM2
	HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);  //SM2 PWM1
	HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_2);  //SM2 PWM2
	HAL_TIM_PWM_Start(&htim8, TIM_CHANNEL_4);  //SM3 PWM1
	HAL_TIM_PWM_Start(&htim8, TIM_CHANNEL_3);  //SM3 PWM2
	HAL_TIM_PWM_Start(&htim8, TIM_CHANNEL_1);  //SM4 PWM1
	HAL_TIM_PWM_Start(&htim8, TIM_CHANNEL_2);  //SM4 PWM2
}

void Hct_SM_Enable(void){
// Enable initialisation of SMs in the bottom stack
	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, 1);   //SM5 Enable
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2, 1);   //SM6 Enable
	HAL_GPIO_WritePin(GPIOE, GPIO_PIN_12, 1);  //SM7 Enable
	HAL_GPIO_WritePin(GPIOD, GPIO_PIN_8, 1);   //SM8 Enable

// Enable initialisation of SMs in the top stack
	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, 1);  //SM1 Enable
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, 1);   //SM2 Enable
	HAL_GPIO_WritePin(GPIOD, GPIO_PIN_7, 1);   //SM3 Enable
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, 1);   //SM4 Enable
}

void Hct_SM_Disable(void){
// Enable initialisation of SMs in the bottom stack
	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, 0);   //SM5 Enable
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2, 0);   //SM6 Enable
	HAL_GPIO_WritePin(GPIOE, GPIO_PIN_12, 0);  //SM7 Enable
	HAL_GPIO_WritePin(GPIOD, GPIO_PIN_8, 0);   //SM8 Enable

// Enable initialisation of SMs in the top stack
	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, 0);  //SM1 Enable
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, 0);   //SM2 Enable
	HAL_GPIO_WritePin(GPIOD, GPIO_PIN_7, 0);   //SM3 Enable
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, 0);   //SM4 Enable

}

void Update_Vref(void)
{
	Vref_top = (float) USB_RX[0] / 6 - 20;
	Vref_bottom = (float) USB_RX[1] /6  - 20;
}


void Read_Stack_Current(void)
{
	HAL_ADC_Start_IT(&hadc1);
	HAL_ADC_Start_IT(&hadc2);
}

void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc)
{
	if (hadc->Instance == ADC1) {
		Vadc_top = HAL_ADC_GetValue(&hadc1) * 3.31 / 4095;
		I_top = (Vadc_top - 2.555) / 0.185;
		USB_TX[0] = 40 * I_top + 120;
		if ((I_top > Is_Max) || (I_top < Is_Min)) { Flag_Error = 1; } // Over current Alert
		HAL_ADC_Stop_IT(&hadc1);
	}

	if (hadc->Instance == ADC2) {
		Vadc_bottom = HAL_ADC_GetValue(&hadc2) * 3.31 / 4095;
		I_bottom = (Vadc_bottom - 2.525) / 0.185;

		USB_TX[1] = 40 * I_bottom + 120;
		if ((I_bottom > Is_Max) || (I_bottom < Is_Min)) { Flag_Error = 1; } // Over current Alert
		HAL_ADC_Stop_IT(&hadc2);
	}
}

void Read_SM_Voltage(void){

	/* SM7 (SM3 at bottom stack) */
	switch (capture_Flag[2]){
	case 0:
		capture_Flag[2]++;
		__HAL_TIM_SET_CAPTUREPOLARITY(&htim4, TIM_CHANNEL_1, TIM_INPUTCHANNELPOLARITY_RISING); //Capture rising edge
		HAL_TIM_IC_Start_IT(&htim4, TIM_CHANNEL_1);	                 //Input capture start
		break;
	case 3:
		Input_PWM_Period[2] = (capture_2ndedge[2]- capture_1stedge[2]); // Period (us)

		if ((Input_PWM_Period[2] < 500) && (Input_PWM_Period[2] > 2)) { Vsm_bottom[2] = ((float)Input_PWM_Period[2] / 2-1) * 0.0611;}// Avoid data overflow
		else if (Input_PWM_Period[2] >= 500) {Vsm_bottom[2] = 15;}
		else { Vsm_bottom[2] = 0;}

		if ((Vsm_bottom[2] > Vsm_Max) || (Vsm_bottom[2] < Vsm_Min)) { // Over voltage Alert: Twice-> Error Alert
			switch (Vsm_Flag[2]) {
				case 0:
					Vsm_Flag[2] = 1;
					break;
				case 1:
					Flag_Error = 1;
					break;
			}
		} else { Vsm_Flag[2] = 0; }

		capture_Flag[2] = 0;                                            // Clear the capture signal
		break;
	}

	/* SM3 (SM3 at top stack) */
	switch (capture_Flag[6]){
	case 0:
		capture_Flag[6]++;
		__HAL_TIM_SET_CAPTUREPOLARITY(&htim2, TIM_CHANNEL_1, TIM_INPUTCHANNELPOLARITY_RISING); //Capture rising edge
		HAL_TIM_IC_Start_IT(&htim2, TIM_CHANNEL_1);	                 //Input capture start
		break;
	case 3:
		Input_PWM_Period[6] = (capture_2ndedge[6]- capture_1stedge[6]); //Period (us)

		if ((Input_PWM_Period[6] < 500) && (Input_PWM_Period[6] > 2)) { Vsm_top[2] = ((float)Input_PWM_Period[6] / 2-1) * 0.0611;}// Avoid data overflow
		else if (Input_PWM_Period[6] >= 500) { Vsm_top[2] = 15; }
		else { Vsm_top[2] = 0; }

		if ((Vsm_top[2] > Vsm_Max) || (Vsm_top[2] < Vsm_Min)) { // Over voltage Alert: Twice-> Error Alert
			switch (Vsm_Flag[6]) {
				case 0:
					Vsm_Flag[6] = 1;
					break;
				case 1:
					Flag_Error = 1;
					break;
			}
		} else { Vsm_Flag[6] = 0; }

		capture_Flag[6] = 0;                                          //Clear the capture signal
		break;
	}

	/* SM5 (SM1 at bottom stack)*/
	switch (capture_Flag[0]){
	case 0:
		capture_Flag[0]++;
		__HAL_TIM_SET_CAPTUREPOLARITY(&htim2, TIM_CHANNEL_2, TIM_INPUTCHANNELPOLARITY_RISING); //Capture rising edge
		HAL_TIM_IC_Start_IT(&htim2, TIM_CHANNEL_2);	                   //Input capture start
		break;
	case 3:
		Input_PWM_Period[0] = (capture_2ndedge[0] - capture_1stedge[0]); //Period (us)

		if ((Input_PWM_Period[0] < 500) && (Input_PWM_Period[0] > 2)) { Vsm_bottom[0] = ((float)Input_PWM_Period[0] / 2-1) * 0.0611;}
		else if (Input_PWM_Period[0] >= 500) { Vsm_bottom[0] = 15; }
		else { Vsm_bottom[0] = 0; }

		if ((Vsm_bottom[0] > Vsm_Max) || (Vsm_bottom[0] < Vsm_Min)) { // Over voltage Alert: Twice-> Error Alert
			switch (Vsm_Flag[0]) {
				case 0:
					Vsm_Flag[0] = 1;
					break;
				case 1:
					Flag_Error = 1;
					break;
			}
		} else { Vsm_Flag[0] = 0; }

		capture_Flag[0] = 0;                                             //Clear the capture signal
		break;
	}

	/* SM2 (SM2 at top stack)*/
	switch (capture_Flag[5]){
	case 0:
		capture_Flag[5]++;
		__HAL_TIM_SET_CAPTUREPOLARITY(&htim4, TIM_CHANNEL_2, TIM_INPUTCHANNELPOLARITY_RISING); //Capture rising edge
		HAL_TIM_IC_Start_IT(&htim4, TIM_CHANNEL_2);	                 //Input capture start
		break;
	case 3:
		Input_PWM_Period[5] = (capture_2ndedge[5]- capture_1stedge[5]); //Period (us)

		if ((Input_PWM_Period[5] < 500) && (Input_PWM_Period[5] > 2)) {Vsm_top[1] = ((float)Input_PWM_Period[5] / 2-1) * 0.0611;}
		else if (Input_PWM_Period[5] >= 500) {Vsm_top[1] = 15;}
		else {Vsm_top[1] = 0;}

		if ((Vsm_top[1] > Vsm_Max) || (Vsm_top[1] < Vsm_Min)) { // Over voltage Alert: Twice-> Error Alert
			switch (Vsm_Flag[5]) {
				case 0:
					Vsm_Flag[5] = 1;
					break;
				case 1:
					Flag_Error = 1;
					break;
			}
		} else { Vsm_Flag[5] = 0; }

		capture_Flag[5] = 0;                                            //Clear the capture signal
		break;
	}

	/* SM8 (SM4 at bottom stack)*/
	switch (capture_Flag[3]){
	case 0:
		capture_Flag[3]++;
		__HAL_TIM_SET_CAPTUREPOLARITY(&htim2, TIM_CHANNEL_3, TIM_INPUTCHANNELPOLARITY_RISING); //Capture rising edge
		HAL_TIM_IC_Start_IT(&htim2, TIM_CHANNEL_3);	                 //Input capture start
		break;
	case 3:
		Input_PWM_Period[3] = (capture_2ndedge[3]- capture_1stedge[3]); //Period (us)

		if ((Input_PWM_Period[3] < 500) && (Input_PWM_Period[3] > 2)) {Vsm_bottom[3] = ((float)Input_PWM_Period[3] / 2-1) * 0.0611;}
		else if (Input_PWM_Period[3] >= 500) {Vsm_bottom[3] = 15;}
		else {Vsm_bottom[3] = 0;}

		if ((Vsm_bottom[3] > Vsm_Max) || (Vsm_bottom[3] < Vsm_Min)) { // Over voltage Alert: Twice-> Error Alert
			switch (Vsm_Flag[3]) {
				case 0:
					Vsm_Flag[3] = 1;
					break;
				case 1:
					Flag_Error = 1;
					break;
			}
		} else { Vsm_Flag[3] = 0; }

		capture_Flag[3] = 0;                     //Clear the capture signal
		break;
	}

	/* SM4 (SM4 at top stack)*/
	switch (capture_Flag[7]){
	case 0:
		capture_Flag[7]++;
		__HAL_TIM_SET_CAPTUREPOLARITY(&htim4, TIM_CHANNEL_3, TIM_INPUTCHANNELPOLARITY_RISING); //Capture rising edge
		HAL_TIM_IC_Start_IT(&htim4, TIM_CHANNEL_3);
		break;
	case 3:
		  Input_PWM_Period[7] = (capture_2ndedge[7]- capture_1stedge[7]); //Period (us)

		  if ((Input_PWM_Period[7] < 500) && (Input_PWM_Period[7] > 2)) { Vsm_top[3] = ((float)Input_PWM_Period[7] / 2-1) * 0.0611;}
		  else if (Input_PWM_Period[7] >= 500) {Vsm_top[3] = 15;}
		  else {Vsm_top[3] = 0;}

		  if ((Vsm_top[3] > Vsm_Max) || (Vsm_top[3] < Vsm_Min)) { // Over voltage Alert: Twice-> Error Alert
			  switch (Vsm_Flag[7]) {
			  case 0:
				  Vsm_Flag[7] = 1;
				  break;
			  case 1:
				  Flag_Error = 1;
				  break;
			  }
		  } else { Vsm_Flag[7] = 0; }

		  capture_Flag[7] = 0;                                            //Clear the capture signal
		  break;
	}

	/* SM6 (SM2 at bottom stack)*/
	switch (capture_Flag[1]){
	case 0:
		capture_Flag[1]++;
		__HAL_TIM_SET_CAPTUREPOLARITY(&htim2, TIM_CHANNEL_4, TIM_INPUTCHANNELPOLARITY_RISING); //Capture rising edge
		HAL_TIM_IC_Start_IT(&htim2, TIM_CHANNEL_4);	                   //Input capture start
		break;
	case 3:
		Input_PWM_Period[1] = (capture_2ndedge[1] - capture_1stedge[1]); //Period (us)

		if ((Input_PWM_Period[1] < 500) && (Input_PWM_Period[1] > 2)) {Vsm_bottom[1] = ((float)Input_PWM_Period[1] / 2-1) * 0.0611;}
		else if (Input_PWM_Period[1] >= 500) {Vsm_bottom[1] = 15;}
		else {Vsm_bottom[1] = 0;}

		if ((Vsm_bottom[1] > Vsm_Max) || (Vsm_bottom[1] < Vsm_Min)) { // Over voltage Alert: Twice-> Error Alert
			switch (Vsm_Flag[1]) {
				case 0:
					Vsm_Flag[1] = 1;
					break;
				case 1:
					Flag_Error = 1;
					break;
			}
		} else { Vsm_Flag[1] = 0; }

		capture_Flag[1] = 0;                    //Clear the capture signal
		break;
	}

	/* SM1 (SM1 at top stack)*/
	switch (capture_Flag[4]){
	case 0:
		capture_Flag[4]++;
		__HAL_TIM_SET_CAPTUREPOLARITY(&htim4, TIM_CHANNEL_4, TIM_INPUTCHANNELPOLARITY_RISING); //Capture rising edge
		HAL_TIM_IC_Start_IT(&htim4, TIM_CHANNEL_4);	                 //Input capture start
		break;
	case 3:
		Input_PWM_Period[4] = (capture_2ndedge[4]- capture_1stedge[4]); //Period (us)

		if ((Input_PWM_Period[4] < 500) && (Input_PWM_Period[4] > 2)) {
			Vsm_top[0] = ((float)Input_PWM_Period[4] / 2-1) * 0.0611;//* 5 * 147 / 47 / 256 = 0.06108710106...
		}
		else if (Input_PWM_Period[4] >= 500) {Vsm_top[0] = 15;}
		else {Vsm_top[0] = 0;}

		if ((Vsm_top[0] > Vsm_Max) || (Vsm_top[0] < Vsm_Min)) { // Over voltage Alert: Twice-> Error Alert
			switch (Vsm_Flag[4]) {
				case 0:
					Vsm_Flag[4] = 1;
					break;
				case 1:
					Flag_Error = 1;
					break;
			}
		} else { Vsm_Flag[4] = 0; }

		capture_Flag[4] = 0;                                //Clear the capture signal
		break;
	}

	Vsm_top_Aver = (Vsm_top[0] + Vsm_top[1] + Vsm_top[2] + Vsm_top[3]) / 4;               // Average SM voltage in the top stack
	Vsm_bottom_Aver = (Vsm_bottom[0] + Vsm_bottom[1] + Vsm_bottom[2] + Vsm_bottom[3]) / 4;// Average SM voltage in the bottom stack
	Vsm_Aver = (Vsm_top_Aver + Vsm_bottom_Aver)/2;

	//Estack = sum of 1/2 CV^2, C=3Csm=0.0204F
	Estack_top = 0.0102 * (Vsm_top[0] * Vsm_top[0] + Vsm_top[1] * Vsm_top[1] + Vsm_top[2] * Vsm_top[2] + Vsm_top[3] * Vsm_top[3]);
	Estack_bottom = 0.0102 * (Vsm_bottom[0] * Vsm_bottom[0] + Vsm_bottom[1] * Vsm_bottom[1] + Vsm_bottom[2] * Vsm_bottom[2] + Vsm_bottom[3] * Vsm_bottom[3]);
	if(Estack_top > 5.1){
		Estack_top = 5.1;
	}

	if(Estack_bottom > 5.1){
		Estack_bottom = 5.1;
	}

	USB_TX[2] = Estack_top *50;
	USB_TX[3] = Estack_bottom *50;

}

void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim){

	if(htim->Instance == TIM2){
		if(htim->Channel == HAL_TIM_ACTIVE_CHANNEL_2){// SM1
			switch(capture_Flag[0]){
			case 1:
				capture_1stedge[0] = HAL_TIM_ReadCapturedValue(&htim2,TIM_CHANNEL_2);// Capture the 1st Raising edge
				__HAL_TIM_SET_CAPTUREPOLARITY(&htim2, TIM_CHANNEL_2, TIM_INPUTCHANNELPOLARITY_RISING);
				capture_Flag[0]++;
				break;
			case 2:
				capture_2ndedge[0] = HAL_TIM_ReadCapturedValue(&htim2,TIM_CHANNEL_2);//Capture the 2nd Raising edge
				HAL_TIM_IC_Stop_IT(&htim2,TIM_CHANNEL_2);                            //Stop capture
				capture_Flag[0]++;
			}
		}
		else if(htim->Channel == HAL_TIM_ACTIVE_CHANNEL_4){// SM2
			switch(capture_Flag[1]){
			case 1:
				capture_1stedge[1] = HAL_TIM_ReadCapturedValue(&htim2,TIM_CHANNEL_4);// Capture the 1st Raising edge
				__HAL_TIM_SET_CAPTUREPOLARITY(&htim2, TIM_CHANNEL_4, TIM_INPUTCHANNELPOLARITY_RISING);
				capture_Flag[1]++;
				break;
			case 2:
				capture_2ndedge[1] = HAL_TIM_ReadCapturedValue(&htim2,TIM_CHANNEL_4);//Capture the 2nd Raising edge
				HAL_TIM_IC_Stop_IT(&htim2,TIM_CHANNEL_4);                            //Stop capture
				capture_Flag[1]++;
			}
		}
		else if(htim->Channel == HAL_TIM_ACTIVE_CHANNEL_3){// SM4
			switch(capture_Flag[3]){
			case 1:
				capture_1stedge[3] = HAL_TIM_ReadCapturedValue(&htim2,TIM_CHANNEL_3);// Capture the 1st Raising edge
				__HAL_TIM_SET_CAPTUREPOLARITY(&htim2, TIM_CHANNEL_3, TIM_INPUTCHANNELPOLARITY_RISING);
				capture_Flag[3]++;
				break;
			case 2:
				capture_2ndedge[3] = HAL_TIM_ReadCapturedValue(&htim2,TIM_CHANNEL_3);//Capture the 2nd Raising edge
				HAL_TIM_IC_Stop_IT(&htim2,TIM_CHANNEL_3);                            //Stop capture
				capture_Flag[3]++;
			}
		}
		else if(htim->Channel == HAL_TIM_ACTIVE_CHANNEL_1){// SM7
			switch(capture_Flag[6]){
			case 1:
				capture_1stedge[6] = HAL_TIM_ReadCapturedValue(&htim2,TIM_CHANNEL_1);// Capture the 1st Raising edge
				__HAL_TIM_SET_CAPTUREPOLARITY(&htim2, TIM_CHANNEL_1, TIM_INPUTCHANNELPOLARITY_RISING);
				capture_Flag[6]++;
				break;
			case 2:
				capture_2ndedge[6] = HAL_TIM_ReadCapturedValue(&htim2,TIM_CHANNEL_1);//Capture the 2nd Raising edge
				HAL_TIM_IC_Stop_IT(&htim2,TIM_CHANNEL_1);                            //Stop capture
				capture_Flag[6]++;
			}
		}
	}

	else if(htim->Instance == TIM4){
		if(htim->Channel == HAL_TIM_ACTIVE_CHANNEL_1){// SM3
			switch(capture_Flag[2]){
			case 1:
				capture_1stedge[2] = HAL_TIM_ReadCapturedValue(&htim4,TIM_CHANNEL_1);// Capture the 1st Raising edge
				__HAL_TIM_SET_CAPTUREPOLARITY(&htim4, TIM_CHANNEL_1, TIM_INPUTCHANNELPOLARITY_RISING);
				capture_Flag[2]++;
				break;
			case 2:
				capture_2ndedge[2] = HAL_TIM_ReadCapturedValue(&htim4,TIM_CHANNEL_1);//Capture the 2nd Raising edge
				HAL_TIM_IC_Stop_IT(&htim4,TIM_CHANNEL_1);                            //Stop capture
				capture_Flag[2]++;
				break;
			}
		}
		else if(htim->Channel == HAL_TIM_ACTIVE_CHANNEL_4){// SM5
			switch(capture_Flag[4]){
			case 1:
				capture_1stedge[4] = HAL_TIM_ReadCapturedValue(&htim4,TIM_CHANNEL_4);// Capture the 1st Raising edge
				__HAL_TIM_SET_CAPTUREPOLARITY(&htim4, TIM_CHANNEL_4, TIM_INPUTCHANNELPOLARITY_RISING);
				capture_Flag[4]++;
				break;
			case 2:
				capture_2ndedge[4] = HAL_TIM_ReadCapturedValue(&htim4,TIM_CHANNEL_4);//Capture the 2nd Raising edge
				HAL_TIM_IC_Stop_IT(&htim4,TIM_CHANNEL_4);                            //Stop capture
				capture_Flag[4]++;
			}
		}

		else if(htim->Channel == HAL_TIM_ACTIVE_CHANNEL_2){// SM6
			switch(capture_Flag[5]){
			case 1:
				capture_1stedge[5] = HAL_TIM_ReadCapturedValue(&htim4,TIM_CHANNEL_2);// Capture the 1st Raising edge
				__HAL_TIM_SET_CAPTUREPOLARITY(&htim4, TIM_CHANNEL_2, TIM_INPUTCHANNELPOLARITY_RISING);
				capture_Flag[5]++;
				break;
			case 2:
				capture_2ndedge[5] = HAL_TIM_ReadCapturedValue(&htim4,TIM_CHANNEL_2);//Capture the 2nd Raising edge
				HAL_TIM_IC_Stop_IT(&htim4,TIM_CHANNEL_2);                            //Stop capture
				capture_Flag[5]++;
			}
		}
		else if(htim->Channel == HAL_TIM_ACTIVE_CHANNEL_3){// SM8
			switch(capture_Flag[7]){
			case 1:
				capture_1stedge[7] = HAL_TIM_ReadCapturedValue(&htim4,TIM_CHANNEL_3);// Capture the 1st Raising edge
				__HAL_TIM_SET_CAPTUREPOLARITY(&htim4, TIM_CHANNEL_3, TIM_INPUTCHANNELPOLARITY_RISING);
				capture_Flag[7]++;
				break;
			case 2:
				capture_2ndedge[7] = HAL_TIM_ReadCapturedValue(&htim4,TIM_CHANNEL_3);//Capture the 2nd Raising edge
				HAL_TIM_IC_Stop_IT(&htim4,TIM_CHANNEL_3);                            //Stop capture
				capture_Flag[7]++;
			}
		}
	}
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

